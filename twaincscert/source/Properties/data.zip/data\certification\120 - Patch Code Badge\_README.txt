Patch Codes can be found online.
Here are some resources as of 19-Aug-2021

https://patchcode.kodakalaris.com/en/index.html
http://www.alliancegroup.co.uk/patch-codes.htm

If the links don't work, search for:
Patch Code Samples
Patch Code Creator
Patch Code Generator

Note that TWAIN only recognizes the following patches, ones other
than these may be recognized by a TWAIN driver as a custom feature,
but will not be recognized by the certification test.
  PATCH 1
  PATCH 2
  PATCH 3
  PATCH 4
  PATCH 6
  PATCH T (transfer)
