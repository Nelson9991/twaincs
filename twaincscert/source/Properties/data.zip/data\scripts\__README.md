These are convenience scripts that can be used for interactively
exploring data sources.  Files delivered by the tool may overwrite
any changes made by the user.  So be careful.  Keep a backup copy
of new or updated scripts someplace safe.